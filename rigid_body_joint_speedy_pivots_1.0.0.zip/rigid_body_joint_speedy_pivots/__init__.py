# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Rigid Body Joint Speedy Pivots",
    "description": "adds buttons to rigid body joint constraint",
    "author": "vuaieo",
    "version": (1, 0, 0),
    "blender": (3, 10, 0),
    "location": "Editor Type: Properties > Object Constraints > Add Object Constraint > Rigid Body Joint",
    "warning": "",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Physics"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
rigid_body_joint_speedy_pivots = {
    "edit_select_mode": [], 
    "sn_3d_cursor_location": [], 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
###############   EVALUATED CODE
#######   Rigid Body Joint Speedy Pivots
def sn_append_panel_DAE5F(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.place_pivot_to_selection",text=r"Pivot to Selection",emboss=True,depress=False,icon_value=260)
    except Exception as exc:
        print(str(exc) + " | Error in Object Brigidbodyjointconstraint when adding to panel")


class SNA_OT_Place_Pivot_To_Selection(bpy.types.Operator):
    bl_idname = "sna.place_pivot_to_selection"
    bl_label = "Place Pivot To Selection"
    bl_description = "Places the Pivot to the Selection of this Constraint ( location of pivot depends on Transform Pivot Point type ).  This button works only in edit mode"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            if "EDIT_MESH"==bpy.context.mode:
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_assign('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                rigid_body_joint_speedy_pivots["edit_select_mode"] = [bpy.context.tool_settings.mesh_select_mode[0], bpy.context.tool_settings.mesh_select_mode[1], bpy.context.tool_settings.mesh_select_mode[2], ]
                rigid_body_joint_speedy_pivots["sn_3d_cursor_location"] = [bpy.context.scene.cursor.location[0], bpy.context.scene.cursor.location[1], bpy.context.scene.cursor.location[2], ]
                bpy.ops.mesh.select_mode(action='ENABLE' if True else 'DISABLE', type='VERT', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='EDGE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='FACE', use_extend=True)
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.primitive_vert_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                for_node_B2BC8 = 0
                for_node_index_B2BC8 = 0
                for for_node_index_B2BC8, for_node_B2BC8 in enumerate(bpy.context.active_object.data.vertices):
                    pass
                sn_cast_blend_data(bpy.context.active_object.constraints.active).pivot_x = for_node_B2BC8.co[0]
                sn_cast_blend_data(bpy.context.active_object.constraints.active).pivot_y = for_node_B2BC8.co[1]
                sn_cast_blend_data(bpy.context.active_object.constraints.active).pivot_z = for_node_B2BC8.co[2]
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"VERT", [("VERT","Vertices",""),("EDGE","Edges",""),("FACE","Faces",""),("EDGE_FACE","Only Edges & Faces",""),("ONLY_FACE","Only Faces",""),]),)
                bpy.context.area.type = op_reset_context
                bpy.ops.mesh.select_mode(action='ENABLE' if sn_cast_boolean_vector(rigid_body_joint_speedy_pivots["edit_select_mode"], 3)[0] else 'DISABLE', type='VERT', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if sn_cast_boolean_vector(rigid_body_joint_speedy_pivots["edit_select_mode"], 3)[1] else 'DISABLE', type='EDGE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if sn_cast_boolean_vector(rigid_body_joint_speedy_pivots["edit_select_mode"], 3)[2] else 'DISABLE', type='FACE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='VERT', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='EDGE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='FACE', use_extend=True)
                bpy.context.scene.cursor.location = (sn_cast_float_vector(rigid_body_joint_speedy_pivots["sn_3d_cursor_location"], 3)[0],sn_cast_float_vector(rigid_body_joint_speedy_pivots["sn_3d_cursor_location"], 3)[1],sn_cast_float_vector(rigid_body_joint_speedy_pivots["sn_3d_cursor_location"], 3)[2],)
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_select('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.object.vertex_group_remove('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',all=False,all_unlocked=False,)
                bpy.context.area.type = op_reset_context
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Place Pivot To Selection")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Place Pivot To Selection")
        return context.window_manager.invoke_confirm(self, event)


#######   Rigid Body Joint Pivot to 3D Cursor Button
def sn_append_panel_734D3(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.pivot_to_3d_cursor",text=r"Pivot to 3D Cursor",emboss=True,depress=False,icon_value=620)
    except Exception as exc:
        print(str(exc) + " | Error in Object Brigidbodyjointconstraint when adding to panel")


class SNA_OT_Pivot_To_3D_Cursor(bpy.types.Operator):
    bl_idname = "sna.pivot_to_3d_cursor"
    bl_label = "Pivot To 3D Cursor"
    bl_description = "Places the Pivot of this Constraint to 3D Cursor position.  this button works only in Edit mode"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            if "EDIT_MESH"==bpy.context.mode:
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_assign_new('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.primitive_vert_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                for_node_52D62 = 0
                for_node_index_52D62 = 0
                for for_node_index_52D62, for_node_52D62 in enumerate(bpy.context.active_object.data.vertices):
                    pass
                bpy.context.active_object.constraints.active.pivot_x = for_node_52D62.co[0]
                bpy.context.active_object.constraints.active.pivot_y = for_node_52D62.co[1]
                bpy.context.active_object.constraints.active.pivot_z = for_node_52D62.co[2]
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"VERT", [("VERT","Vertices",""),("EDGE","Edges",""),("FACE","Faces",""),("EDGE_FACE","Only Edges & Faces",""),("ONLY_FACE","Only Faces",""),]),)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_select('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_remove('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',all=False,all_unlocked=False,)
                bpy.context.area.type = op_reset_context
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Pivot To 3D Cursor")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Pivot To 3D Cursor")
        return context.window_manager.invoke_confirm(self, event)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.rigid_body_joint_speedy_pivots_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.rigid_body_joint_speedy_pivots_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.rigid_body_joint_speedy_pivots_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    pass

def sn_unregister_properties():
    pass


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Place_Pivot_To_Selection)
    bpy.utils.register_class(SNA_OT_Pivot_To_3D_Cursor)
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.append(sn_append_panel_DAE5F)
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.append(sn_append_panel_734D3)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.remove(sn_append_panel_734D3)
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.remove(sn_append_panel_DAE5F)
    bpy.utils.unregister_class(SNA_OT_Pivot_To_3D_Cursor)
    bpy.utils.unregister_class(SNA_OT_Place_Pivot_To_Selection)
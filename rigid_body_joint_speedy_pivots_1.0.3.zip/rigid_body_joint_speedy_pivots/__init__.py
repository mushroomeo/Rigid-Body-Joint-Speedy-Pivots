# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#
# This addon was created with the Serpens - Visual Scripting Addon.
# This code is generated from nodes and is not intended for manual editing.
# You can find out more about Serpens at <https://blendermarket.com/products/serpens>.


bl_info = {
    "name": "Rigid Body Joint Speedy Pivots",
    "description": "adds buttons to rigid body joint constraint",
    "author": "vuaieo",
    "version": (1, 0, 3),
    "blender": (3, 10, 0),
    "location": "Shift + V and in Editor Type: Properties > Object Constraints > Add Object Constraint > Rigid Body Joint",
    "warning": "there some bugs but not always so dunno",
    "wiki_url": "",
    "tracker_url": "",
    "category": "Physics"
}


###############   IMPORTS
import bpy
from bpy.utils import previews
import os
import math


###############   INITALIZE VARIABLES
rigid_body_joint_speedy_pivots = {
    "edit_select_mode": [], 
    "sn_3d_cursor_location": [], 
    }
a_pivot_for_each_selected_vertex__pie_menu = {
    "active_object_name": "", 
    "selected_object_name": "", 
    "selected_vertex": [], 
    }


###############   SERPENS FUNCTIONS
def exec_line(line):
    exec(line)

def sn_print(tree_name, *args):
    if tree_name in bpy.data.node_groups:
        item = bpy.data.node_groups[tree_name].sn_graphs[0].prints.add()
        for arg in args:
            item.value += str(arg) + ";;;"
        if bpy.context and bpy.context.screen:
            for area in bpy.context.screen.areas:
                area.tag_redraw()
    print(*args)

def sn_cast_string(value):
    return str(value)

def sn_cast_boolean(value):
    if type(value) == tuple:
        for data in value:
            if bool(data):
                return True
        return False
    return bool(value)

def sn_cast_float(value):
    if type(value) == str:
        try:
            value = float(value)
            return value
        except:
            return float(bool(value))
    elif type(value) == tuple:
        return float(value[0])
    elif type(value) == list:
        return float(len(value))
    elif not type(value) in [float, int, bool]:
        try:
            value = len(value)
            return float(value)
        except:
            return float(bool(value))
    return float(value)

def sn_cast_int(value):
    return int(sn_cast_float(value))

def sn_cast_boolean_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(bool(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(bool(value[i]) if len(value) > i else bool(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_boolean_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_boolean_vector(value, size)
        except:
            return sn_cast_boolean_vector(bool(value), size)

def sn_cast_float_vector(value, size):
    if type(value) in [str, bool, int, float]:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value))
        return tuple(return_value)
    elif type(value) == tuple:
        return_value = []
        for i in range(size):
            return_value.append(sn_cast_float(value[i]) if len(value) > i else sn_cast_float(value[0]))
        return tuple(return_value)
    elif type(value) == list:
        return sn_cast_float_vector(tuple(value), size)
    else:
        try:
            value = tuple(value)
            return sn_cast_float_vector(value, size)
        except:
            return sn_cast_float_vector(sn_cast_float(value), size)

def sn_cast_int_vector(value, size):
    return tuple(map(int, sn_cast_float_vector(value, size)))

def sn_cast_color(value, use_alpha):
    length = 4 if use_alpha else 3
    value = sn_cast_float_vector(value, length)
    tuple_list = []
    for data in range(length):
        data = value[data] if len(value) > data else value[0]
        tuple_list.append(sn_cast_float(min(1, max(0, data))))
    return tuple(tuple_list)

def sn_cast_list(value):
    if type(value) in [str, tuple, list]:
        return list(value)
    elif type(value) in [int, float, bool]:
        return [value]
    else:
        try:
            value = list(value)
            return value
        except:
            return [value]

def sn_cast_blend_data(value):
    if hasattr(value, "bl_rna"):
        return value
    elif type(value) in [tuple, bool, int, float, list]:
        return None
    elif type(value) == str:
        try:
            value = eval(value)
            return value
        except:
            return None
    else:
        return None

def sn_cast_enum(string, enum_values):
    for item in enum_values:
        if item[1] == string:
            return item[0]
        elif item[0] == string.upper():
            return item[0]
    return string


###############   IMPERATIVE CODE
#######   A pivot for each Selected vertex + Pie Menu
def sn_handle_script_line_exception(exc, line):
    print("# # # # # # # # SCRIPT LINE ERROR # # # # # # # #")
    print("Line:", line)
    raise exc
addon_keymaps = {}


###############   EVALUATED CODE
#######   Rigid Body Joint Speedy Pivots
class SNA_OT_Place_Pivot_To_Selection(bpy.types.Operator):
    bl_idname = "sna.place_pivot_to_selection"
    bl_label = "Place Pivot To Selection"
    bl_description = "Places the Pivot to the Selection of this Constraint ( location of pivot depends on Transform Pivot Point type ).  This button works only in edit mode"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            if "EDIT_MESH"==bpy.context.mode:
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_assign('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                rigid_body_joint_speedy_pivots["edit_select_mode"] = [bpy.context.tool_settings.mesh_select_mode[0], bpy.context.tool_settings.mesh_select_mode[1], bpy.context.tool_settings.mesh_select_mode[2], ]
                rigid_body_joint_speedy_pivots["sn_3d_cursor_location"] = [bpy.context.scene.cursor.location[0], bpy.context.scene.cursor.location[1], bpy.context.scene.cursor.location[2], ]
                bpy.ops.mesh.select_mode(action='ENABLE' if True else 'DISABLE', type='VERT', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='EDGE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='FACE', use_extend=True)
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.view3d.snap_cursor_to_selected('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.primitive_vert_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                for_node_B2BC8 = 0
                for_node_index_B2BC8 = 0
                for for_node_index_B2BC8, for_node_B2BC8 in enumerate(bpy.context.active_object.data.vertices):
                    pass
                sn_cast_blend_data(bpy.context.active_object.constraints.active).pivot_x = for_node_B2BC8.co[0]
                sn_cast_blend_data(bpy.context.active_object.constraints.active).pivot_y = for_node_B2BC8.co[1]
                sn_cast_blend_data(bpy.context.active_object.constraints.active).pivot_z = for_node_B2BC8.co[2]
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"VERT", [("VERT","Vertices",""),("EDGE","Edges",""),("FACE","Faces",""),("EDGE_FACE","Only Edges & Faces",""),("ONLY_FACE","Only Faces",""),]),)
                bpy.context.area.type = op_reset_context
                bpy.ops.mesh.select_mode(action='ENABLE' if sn_cast_boolean_vector(rigid_body_joint_speedy_pivots["edit_select_mode"], 3)[0] else 'DISABLE', type='VERT', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if sn_cast_boolean_vector(rigid_body_joint_speedy_pivots["edit_select_mode"], 3)[1] else 'DISABLE', type='EDGE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if sn_cast_boolean_vector(rigid_body_joint_speedy_pivots["edit_select_mode"], 3)[2] else 'DISABLE', type='FACE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='VERT', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='EDGE', use_extend=True)
                bpy.ops.mesh.select_mode(action='ENABLE' if False else 'DISABLE', type='FACE', use_extend=True)
                bpy.context.scene.cursor.location = (sn_cast_float_vector(rigid_body_joint_speedy_pivots["sn_3d_cursor_location"], 3)[0],sn_cast_float_vector(rigid_body_joint_speedy_pivots["sn_3d_cursor_location"], 3)[1],sn_cast_float_vector(rigid_body_joint_speedy_pivots["sn_3d_cursor_location"], 3)[2],)
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_select('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.object.vertex_group_remove('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',all=False,all_unlocked=False,)
                bpy.context.area.type = op_reset_context
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Place Pivot To Selection")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Place Pivot To Selection")
        return context.window_manager.invoke_confirm(self, event)

def sn_append_panel_DAE5F(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.place_pivot_to_selection",text=r"Pivot to Selection",emboss=True,depress=False,icon_value=260)
    except Exception as exc:
        print(str(exc) + " | Error in Object Brigidbodyjointconstraint when adding to panel")


#######   Rigid Body Joint Pivot to 3D Cursor Button
def sn_append_panel_734D3(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.pivot_to_3d_cursor",text=r"Pivot to 3D Cursor",emboss=True,depress=False,icon_value=620)
    except Exception as exc:
        print(str(exc) + " | Error in Object Brigidbodyjointconstraint when adding to panel")


class SNA_OT_Pivot_To_3D_Cursor(bpy.types.Operator):
    bl_idname = "sna.pivot_to_3d_cursor"
    bl_label = "Pivot To 3D Cursor"
    bl_description = "Places the Pivot of this Constraint to 3D Cursor position.  this button works only in Edit mode"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            if "EDIT_MESH"==bpy.context.mode:
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_assign_new('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.primitive_vert_add('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                for_node_52D62 = 0
                for_node_index_52D62 = 0
                for for_node_index_52D62, for_node_52D62 in enumerate(bpy.context.active_object.data.vertices):
                    pass
                bpy.context.active_object.constraints.active.pivot_x = for_node_52D62.co[0]
                bpy.context.active_object.constraints.active.pivot_y = for_node_52D62.co[1]
                bpy.context.active_object.constraints.active.pivot_z = for_node_52D62.co[2]
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'VIEW_3D'
                bpy.ops.mesh.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"VERT", [("VERT","Vertices",""),("EDGE","Edges",""),("FACE","Faces",""),("EDGE_FACE","Only Edges & Faces",""),("ONLY_FACE","Only Faces",""),]),)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_select('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',)
                bpy.context.area.type = op_reset_context
                op_reset_context = bpy.context.area.type
                bpy.context.area.type = 'PROPERTIES'
                bpy.ops.object.vertex_group_remove('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',all=False,all_unlocked=False,)
                bpy.context.area.type = op_reset_context
            else:
                pass
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Pivot To 3D Cursor")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Pivot To 3D Cursor")
        return context.window_manager.invoke_confirm(self, event)


#######   A pivot for each Selected vertex + Pie Menu
class SNA_OT_Add_Constraint_Rbj_Pivot_To_Each_Selected_Vertex(bpy.types.Operator):
    bl_idname = "sna.add_constraint_rbj_pivot_to_each_selected_vertex"
    bl_label = "add constraint RBJ Pivot to each selected vertex"
    bl_description = "1. select vertecies of one object 2. go in object mode. select another 1 object ( musst be active object ) and click the button.  works only from object mode"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            a_pivot_for_each_selected_vertex__pie_menu["active_object_name"] = bpy.context.active_object.name
            run_function_on_B2A63 = bpy.context.active_object.select_set(state=False, view_layer=None, )
            for_node_6114B = 0
            for_node_index_6114B = 0
            for for_node_index_6114B, for_node_6114B in enumerate(bpy.context.selected_objects):
                pass
            bpy.context.view_layer.objects.active=for_node_6114B
            a_pivot_for_each_selected_vertex__pie_menu["selected_object_name"] = bpy.context.active_object.name
            if "OBJECT"==bpy.context.mode:
                try: exec(r"bpy.ops.object.editmode_toggle()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.editmode_toggle()")
                try: exec(r"bpy.ops.mesh.duplicate_move(MESH_OT_duplicate={'mode':1}, TRANSFORM_OT_translate={'value':(0, 0, 0), 'orient_axis_ortho':'X', 'orient_type':'GLOBAL', 'orient_matrix':((0, 0, 0), (0, 0, 0), (0, 0, 0)), 'orient_matrix_type':'GLOBAL', 'constraint_axis':(False, False, False), 'mirror':False, 'use_proportional_edit':False, 'proportional_edit_falloff':'SMOOTH', 'proportional_size':1, 'use_proportional_connected':False, 'use_proportional_projected':False, 'snap':False, 'snap_target':'CLOSEST', 'snap_point':(0, 0, 0), 'snap_align':False, 'snap_normal':(0, 0, 0), 'gpencil_strokes':False, 'cursor_transform':False, 'texture_space':False, 'remove_on_cancel':False, 'view2d_edge_pan':False, 'release_confirm':False, 'use_accurate':False, 'use_automerge_and_split':False})")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.mesh.duplicate_move(MESH_OT_duplicate={'mode':1}, TRANSFORM_OT_translate={'value':(0, 0, 0), 'orient_axis_ortho':'X', 'orient_type':'GLOBAL', 'orient_matrix':((0, 0, 0), (0, 0, 0), (0, 0, 0)), 'orient_matrix_type':'GLOBAL', 'constraint_axis':(False, False, False), 'mirror':False, 'use_proportional_edit':False, 'proportional_edit_falloff':'SMOOTH', 'proportional_size':1, 'use_proportional_connected':False, 'use_proportional_projected':False, 'snap':False, 'snap_target':'CLOSEST', 'snap_point':(0, 0, 0), 'snap_align':False, 'snap_normal':(0, 0, 0), 'gpencil_strokes':False, 'cursor_transform':False, 'texture_space':False, 'remove_on_cancel':False, 'view2d_edge_pan':False, 'release_confirm':False, 'use_accurate':False, 'use_automerge_and_split':False})")
                try: exec(r"bpy.ops.mesh.separate(type='SELECTED')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.mesh.separate(type='SELECTED')")
                try: exec(r"bpy.ops.object.editmode_toggle()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.editmode_toggle()")
                run_function_on_613DD = bpy.context.active_object.select_set(state=False, view_layer=None, )
                for_node_0A5E8 = 0
                for_node_index_0A5E8 = 0
                for for_node_index_0A5E8, for_node_0A5E8 in enumerate(bpy.context.selected_objects):
                    pass
                bpy.context.view_layer.objects.active=for_node_0A5E8
                try: exec(r"bpy.ops.object.editmode_toggle()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.editmode_toggle()")
                try: exec(r"bpy.ops.mesh.select_all(action='SELECT')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.mesh.select_all(action='SELECT')")
                new_return_89E8D = bpy.context.active_object.vertex_groups.new(name=r"VGTODELETELATER", )
                try: exec(r"bpy.ops.object.vertex_group_assign()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.vertex_group_assign()")
                try: exec(r"bpy.ops.object.editmode_toggle()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.editmode_toggle()")
                run_function_on_7AACB = bpy.data.objects[a_pivot_for_each_selected_vertex__pie_menu["active_object_name"]].select_set(state=True, view_layer=None, )
                bpy.context.view_layer.objects.active=bpy.data.objects[a_pivot_for_each_selected_vertex__pie_menu["active_object_name"]]
                try: exec(r"bpy.ops.object.join()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.join()")
                try: exec(r"bpy.ops.object.editmode_toggle()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.editmode_toggle()")
                try: exec(r"bpy.ops.mesh.select_all(action='DESELECT')")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.mesh.select_all(action='DESELECT')")
                try: exec(r"bpy.ops.object.vertex_group_add()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.vertex_group_add()")
                try: exec(r"bpy.ops.object.vertex_group_remove(all=False, all_unlocked=False)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.vertex_group_remove(all=False, all_unlocked=False)")
                try: exec(r"bpy.ops.object.vertex_group_select()")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.vertex_group_select()")
                try: exec(r"bpy.ops.object.vertex_group_remove(all=False, all_unlocked=False)")
                except Exception as exc: sn_handle_script_line_exception(exc, r"bpy.ops.object.vertex_group_remove(all=False, all_unlocked=False)")
                for_node_68E75 = 0
                for_node_index_68E75 = 0
                for for_node_index_68E75, for_node_68E75 in enumerate(bpy.context.active_object.data.vertices):
                    a_pivot_for_each_selected_vertex__pie_menu["selected_vertex"] = sn_cast_list(for_node_68E75)
                    if for_node_68E75.select:
                        for_node_89977 = 0
                        for_node_index_89977 = 0
                        for for_node_index_89977, for_node_89977 in enumerate(a_pivot_for_each_selected_vertex__pie_menu["selected_vertex"]):
                            pass
                        new_return_AAF1F = bpy.context.active_object.constraints.new(type=sn_cast_enum(r"RIGID_BODY_JOINT", [("CAMERA_SOLVER","Camera Solver",""),("FOLLOW_TRACK","Follow Track",""),("OBJECT_SOLVER","Object Solver",""),("COPY_LOCATION","Copy Location","Copy the location of a target (with an optional offset), so that they move together"),("COPY_ROTATION","Copy Rotation","Copy the rotation of a target (with an optional offset), so that they rotate together"),("COPY_SCALE","Copy Scale","Copy the scale factors of a target (with an optional offset), so that they are scaled by the same amount"),("COPY_TRANSFORMS","Copy Transforms","Copy all the transformations of a target, so that they move together"),("LIMIT_DISTANCE","Limit Distance","Restrict movements to within a certain distance of a target (at the time of constraint evaluation only)"),("LIMIT_LOCATION","Limit Location","Restrict movement along each axis within given ranges"),("LIMIT_ROTATION","Limit Rotation","Restrict rotation along each axis within given ranges"),("LIMIT_SCALE","Limit Scale","Restrict scaling along each axis with given ranges"),("MAINTAIN_VOLUME","Maintain Volume","Compensate for scaling one axis by applying suitable scaling to the other two axes"),("TRANSFORM","Transformation","Use one transform property from target to control another (or same) property on owner"),("TRANSFORM_CACHE","Transform Cache","Look up the transformation matrix from an external file"),("CLAMP_TO","Clamp To","Restrict movements to lie along a curve by remapping location along curve's longest axis"),("DAMPED_TRACK","Damped Track","Point towards a target by performing the smallest rotation necessary"),("IK","Inverse Kinematics","Control a chain of bones by specifying the endpoint target (Bones only)"),("LOCKED_TRACK","Locked Track","Rotate around the specified ('locked') axis to point towards a target"),("SPLINE_IK","Spline IK","Align chain of bones along a curve (Bones only)"),("STRETCH_TO","Stretch To","Stretch along Y-Axis to point towards a target"),("TRACK_TO","Track To","Legacy tracking constraint prone to twisting artifacts"),("ACTION","Action","Use transform property of target to look up pose for owner from an Action"),("ARMATURE","Armature","Apply weight-blended transformation from multiple bones like the Armature modifier"),("CHILD_OF","Child Of","Make target the 'detachable' parent of owner"),("FLOOR","Floor","Use position (and optionally rotation) of target to define a 'wall' or 'floor' that the owner can not cross"),("FOLLOW_PATH","Follow Path","Use to animate an object/bone following a path"),("PIVOT","Pivot","Change pivot point for transforms (buggy)"),("RIGID_BODY_JOINT","Rigid Body Joint","Use to define a Rigid Body Constraint (for Game Engine use only)"),("SHRINKWRAP","Shrinkwrap","Restrict movements to surface of target mesh"),]), )
                        new_return_AAF1F.pivot_x = sn_cast_blend_data(for_node_89977).co[0]
                        new_return_AAF1F.pivot_y = sn_cast_blend_data(for_node_89977).co[1]
                        new_return_AAF1F.pivot_z = sn_cast_blend_data(for_node_89977).co[2]
                        new_return_AAF1F.target = bpy.data.objects[a_pivot_for_each_selected_vertex__pie_menu["selected_object_name"]]
                        bpy.ops.mesh.delete('INVOKE_DEFAULT' if True else 'EXEC_DEFAULT',type=sn_cast_enum(r"VERT", [("VERT","Vertices",""),("EDGE","Edges",""),("FACE","Faces",""),("EDGE_FACE","Only Edges & Faces",""),("ONLY_FACE","Only Faces",""),]),)
                        for_node_E0EFE = 0
                        for_node_index_E0EFE = 0
                        for for_node_index_E0EFE, for_node_E0EFE in enumerate(bpy.context.active_object.constraints):
                            for_node_E0EFE.show_pivot = True
                    else:
                        pass
            else:
                try: self.report({'INFO'}, message=r"Press the Button while in object mode."+" "+r"Works only from object mode.")
                except: print("Serpens - Can't report in this context!")
        except Exception as exc:
            print(str(exc) + " | Error in execute function of add constraint RBJ Pivot to each selected vertex")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of add constraint RBJ Pivot to each selected vertex")
        return self.execute(context)

def register_key_9D1FB():
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
        kmi = km.keymap_items.new("wm.call_menu_pie",
                                    type= "V",
                                    value= "PRESS",
                                    repeat= False,
                                    ctrl=False,
                                    alt=False,
                                    shift=True)
        kmi.properties.name = "SNA_MT_Rigid_Body_Joint_Constraint_tools_41BA7"
        addon_keymaps['9D1FB'] = (km, kmi)


class SNA_MT_Rigid_Body_Joint_Constraint_tools_41BA7(bpy.types.Menu):
    bl_idname = "SNA_MT_Rigid_Body_Joint_Constraint_tools_41BA7"
    bl_label = "Rigid Body Joint Constraint tools"


    @classmethod
    def poll(cls, context):
        return True

    def draw(self, context):
        try:
            layout = self.layout
            layout = layout.menu_pie()
            op = layout.operator("sna.add_constraint_rbj_pivot_to_each_selected_vertex",text=r"A Pivot For Each Vertex",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.delete_all_constraints_for_all_selected_objects",text=r"Delete All Constraints",emboss=True,depress=True,icon_value=0)
            op = layout.operator("sna.turn_off_display_pivot_for_rbj_constraints",text=r"Disable Display Pivots",emboss=True,depress=False,icon_value=0)
            op = layout.operator("sna.turn_on_display_pivot_for_all_rbj_constraints",text=r"Enable Display Pivots",emboss=True,depress=False,icon_value=0)
        except Exception as exc:
            print(str(exc) + " | Error in Rigid Body Joint Constraint tools pie menu")


#######   Delete RBJ Constraints
class SNA_OT_Delete_All_Constraints_For_All_Selected_Objects(bpy.types.Operator):
    bl_idname = "sna.delete_all_constraints_for_all_selected_objects"
    bl_label = "Delete All Constraints for All Selected Objects"
    bl_description = "removes all Constraints from all Selected Objects"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            for_node_0EE71 = 0
            for_node_index_0EE71 = 0
            for for_node_index_0EE71, for_node_0EE71 in enumerate(bpy.context.selected_objects):
                for_node_421F7 = 0
                for_node_index_421F7 = 0
                for for_node_index_421F7, for_node_421F7 in enumerate(for_node_0EE71.constraints):
                    remove_return_359CF = for_node_0EE71.constraints.remove(constraint=for_node_421F7, )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Delete All Constraints for All Selected Objects")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Delete All Constraints for All Selected Objects")
        return self.execute(context)


class SNA_OT_Delete_All_Constraints_For_Active_Object(bpy.types.Operator):
    bl_idname = "sna.delete_all_constraints_for_active_object"
    bl_label = "Delete All Constraints for Active Object"
    bl_description = "removes all Constraints from Active Object"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            for_node_A4AE0 = 0
            for_node_index_A4AE0 = 0
            for for_node_index_A4AE0, for_node_A4AE0 in enumerate(bpy.context.active_object.constraints):
                remove_return_0C1CF = bpy.context.active_object.constraints.remove(constraint=for_node_A4AE0, )
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Delete All Constraints for Active Object")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Delete All Constraints for Active Object")
        return self.execute(context)

def sn_prepend_panel_940CA(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.delete_all_constraints_for_active_object",text=r"Delete All Constraints",emboss=True,depress=False,icon_value=0)
    except Exception as exc:
        print(str(exc) + " | Error in Object Constraints when adding to panel")


#######   Display Pivot for RBJ Constraints
class SNA_OT_Turn_Off_Display_Pivot_For_Rbj_Constraints_001(bpy.types.Operator):
    bl_idname = "sna.turn_off_display_pivot_for_rbj_constraints_001"
    bl_label = "Turn Off Display Pivot for RBJ Constraints 001"
    bl_description = "Turns off showing RBJ Pivots for Active Object in 3D View"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            for_node_945A6 = 0
            for_node_index_945A6 = 0
            for for_node_index_945A6, for_node_945A6 in enumerate(bpy.context.active_object.constraints):
                for_node_945A6.show_pivot = False
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Turn Off Display Pivot for RBJ Constraints 001")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Turn Off Display Pivot for RBJ Constraints 001")
        return self.execute(context)

def sn_prepend_panel_7937D(self,context):
    try:
        layout = self.layout
        op = layout.operator("sna.turn_off_display_pivot_for_rbj_constraints_001",text=r"Disable Display Pivot",emboss=True,depress=False,icon_value=0)
        op = layout.operator("sna.turn_on_display_pivot_for_all_rbj_constraints_001",text=r"Enable Display Pivot",emboss=True,depress=False,icon_value=0)
    except Exception as exc:
        print(str(exc) + " | Error in Object Constraints when adding to panel")


class SNA_OT_Turn_On_Display_Pivot_For_All_Rbj_Constraints(bpy.types.Operator):
    bl_idname = "sna.turn_on_display_pivot_for_all_rbj_constraints"
    bl_label = "Turn On Display Pivot for all RBJ constraints"
    bl_description = "shows pivot for all selected objects in 3D View"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            for_node_C468A = 0
            for_node_index_C468A = 0
            for for_node_index_C468A, for_node_C468A in enumerate(bpy.context.selected_objects):
                for_node_C7371 = 0
                for_node_index_C7371 = 0
                for for_node_index_C7371, for_node_C7371 in enumerate(for_node_C468A.constraints):
                    for_node_C7371.show_pivot = True
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Turn On Display Pivot for all RBJ constraints")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Turn On Display Pivot for all RBJ constraints")
        return self.execute(context)


class SNA_OT_Turn_Off_Display_Pivot_For_Rbj_Constraints(bpy.types.Operator):
    bl_idname = "sna.turn_off_display_pivot_for_rbj_constraints"
    bl_label = "Turn Off Display Pivot for RBJ Constraints"
    bl_description = "doesnt show pivot for all selected objects in 3D View"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            for_node_C97B0 = 0
            for_node_index_C97B0 = 0
            for for_node_index_C97B0, for_node_C97B0 in enumerate(bpy.context.selected_objects):
                for_node_28E66 = 0
                for_node_index_28E66 = 0
                for for_node_index_28E66, for_node_28E66 in enumerate(for_node_C97B0.constraints):
                    for_node_28E66.show_pivot = False
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Turn Off Display Pivot for RBJ Constraints")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Turn Off Display Pivot for RBJ Constraints")
        return self.execute(context)


class SNA_OT_Turn_On_Display_Pivot_For_All_Rbj_Constraints_001(bpy.types.Operator):
    bl_idname = "sna.turn_on_display_pivot_for_all_rbj_constraints_001"
    bl_label = "Turn On Display Pivot for all RBJ constraints 001"
    bl_description = "shows RBJ pivots for Active Object in 3D View"
    bl_options = {"REGISTER", "UNDO"}


    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        try:
            for_node_AAFF1 = 0
            for_node_index_AAFF1 = 0
            for for_node_index_AAFF1, for_node_AAFF1 in enumerate(bpy.context.active_object.constraints):
                for_node_AAFF1.show_pivot = True
        except Exception as exc:
            print(str(exc) + " | Error in execute function of Turn On Display Pivot for all RBJ constraints 001")
        return {"FINISHED"}

    def invoke(self, context, event):
        try:
            pass
        except Exception as exc:
            print(str(exc) + " | Error in invoke function of Turn On Display Pivot for all RBJ constraints 001")
        return self.execute(context)


###############   REGISTER ICONS
def sn_register_icons():
    icons = []
    bpy.types.Scene.rigid_body_joint_speedy_pivots_icons = bpy.utils.previews.new()
    icons_dir = os.path.join( os.path.dirname( __file__ ), "icons" )
    for icon in icons:
        bpy.types.Scene.rigid_body_joint_speedy_pivots_icons.load( icon, os.path.join( icons_dir, icon + ".png" ), 'IMAGE' )

def sn_unregister_icons():
    bpy.utils.previews.remove( bpy.types.Scene.rigid_body_joint_speedy_pivots_icons )


###############   REGISTER PROPERTIES
def sn_register_properties():
    pass

def sn_unregister_properties():
    pass


###############   REGISTER ADDON
def register():
    sn_register_icons()
    sn_register_properties()
    bpy.utils.register_class(SNA_OT_Place_Pivot_To_Selection)
    bpy.utils.register_class(SNA_OT_Pivot_To_3D_Cursor)
    bpy.utils.register_class(SNA_OT_Add_Constraint_Rbj_Pivot_To_Each_Selected_Vertex)
    register_key_9D1FB()
    bpy.utils.register_class(SNA_MT_Rigid_Body_Joint_Constraint_tools_41BA7)
    bpy.utils.register_class(SNA_OT_Delete_All_Constraints_For_All_Selected_Objects)
    bpy.utils.register_class(SNA_OT_Delete_All_Constraints_For_Active_Object)
    bpy.utils.register_class(SNA_OT_Turn_Off_Display_Pivot_For_Rbj_Constraints_001)
    bpy.utils.register_class(SNA_OT_Turn_On_Display_Pivot_For_All_Rbj_Constraints)
    bpy.utils.register_class(SNA_OT_Turn_Off_Display_Pivot_For_Rbj_Constraints)
    bpy.utils.register_class(SNA_OT_Turn_On_Display_Pivot_For_All_Rbj_Constraints_001)
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.append(sn_append_panel_DAE5F)
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.append(sn_append_panel_734D3)
    bpy.types.OBJECT_PT_constraints.prepend(sn_prepend_panel_940CA)
    bpy.types.OBJECT_PT_constraints.prepend(sn_prepend_panel_7937D)


###############   UNREGISTER ADDON
def unregister():
    sn_unregister_icons()
    sn_unregister_properties()
    bpy.types.OBJECT_PT_constraints.remove(sn_prepend_panel_7937D)
    bpy.types.OBJECT_PT_constraints.remove(sn_prepend_panel_940CA)
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.remove(sn_append_panel_734D3)
    bpy.types.OBJECT_PT_bRigidBodyJointConstraint.remove(sn_append_panel_DAE5F)
    bpy.utils.unregister_class(SNA_OT_Turn_On_Display_Pivot_For_All_Rbj_Constraints_001)
    bpy.utils.unregister_class(SNA_OT_Turn_Off_Display_Pivot_For_Rbj_Constraints)
    bpy.utils.unregister_class(SNA_OT_Turn_On_Display_Pivot_For_All_Rbj_Constraints)
    bpy.utils.unregister_class(SNA_OT_Turn_Off_Display_Pivot_For_Rbj_Constraints_001)
    bpy.utils.unregister_class(SNA_OT_Delete_All_Constraints_For_Active_Object)
    bpy.utils.unregister_class(SNA_OT_Delete_All_Constraints_For_All_Selected_Objects)
    bpy.utils.unregister_class(SNA_MT_Rigid_Body_Joint_Constraint_tools_41BA7)
    for key in addon_keymaps:
        km, kmi = addon_keymaps[key]
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Add_Constraint_Rbj_Pivot_To_Each_Selected_Vertex)
    bpy.utils.unregister_class(SNA_OT_Pivot_To_3D_Cursor)
    bpy.utils.unregister_class(SNA_OT_Place_Pivot_To_Selection)